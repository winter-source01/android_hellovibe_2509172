package com.example.a2509172

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.a2509172.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Hello Vibe 텍스트가 자동으로 표시됩니다
        // 레이아웃에서 @string/hello_vibe와 @string/welcome_message를 참조하고 있습니다
    }
}